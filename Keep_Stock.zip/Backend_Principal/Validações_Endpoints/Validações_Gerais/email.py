import urllib.parse
import requests

token = "22472|U4FnUbPngllkqZz2ZY5ytMlZOjxrtu7i"

def validar_email(email, token):
    base_url = "https://api.invertexto.com/v1/email-validator"

    # Codifica o e-mail para garantir que a URL fique correta
    email_encoded = urllib.parse.quote(email)

    # Monta a URL com o e-mail na rota
    url = f"{base_url}/{email_encoded}"

    # Parametros da query string (neste caso, apenas o token)
    params = {"token": token}

    try:
        # Realiz a requisição GET passando os parametros na URL
        response = requests.get(url, params=params)
        response.raise_for_status() # Levanta exceção para status HTTP de erro

        # Converte a respost para JSON
        data = response.json()

        return data
    
    except requests.exceptions.HTTPError as errh:
        print("Erro HTTP:", errh)
    except requests.exceptions.ConnectionError as errc:
        print("Erro de conexão:", errc)
    except requests.exceptions.Timeout as errt:
        print("Timeout:", errt)
    except requests.exceptions.RequestException as err:
        print("Erro:", err)

    return None

if __name__ == "__main__":
    token = "22472|U4FnUbPngllkqZz2ZY5ytMlZOjxrtu7i"
    email = "allysson.santos1717@gmail.com"

    resultado = validar_email(email, token)

    if resultado:
        print("Resposta da API:")
        print(resultado)
    else:
        print("Não foi possível validar o Email.")