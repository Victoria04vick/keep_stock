import urllib.parse
import requests

token = "22472|U4FnUbPngllkqZz2ZY5ytMlZOjxrtu7i"

def validar_cnpj(cnpj, token):
    # URL base da API
    url = "https://api.invertexto.com/v1/validator"

    # Parametros que serão enviados via query
    params = {
        "token": token,
        "value" : cnpj
    }

    try:
    # Envia a requisição GET com os parâmetros
        response = requests.get(url, params=params)
        response.raise_for_status()

        # Converte a resposta para json
        data = response.json()
        return data
    
    except requests.exceptions.HTTPError as errh:
        print("Erro HTTP:", errh)
    except requests.exceptions.ConnectionError as errc:
        print("Erro de conexão:", errc)
    except requests.exceptions.Timeout as erry:
        print("Timeout:", erry)

    return None

if __name__ == "__main__":
    cnpj = "83.329.827/0001-70"
    token = "22472|U4FnUbPngllkqZz2ZY5ytMlZOjxrtu7i"

    resultado = validar_cnpj(cnpj, token)

    if resultado:
        print("Resposta da API:")
        print(resultado)
    else:
        print("Não foi possível validar o CNPJ.")
