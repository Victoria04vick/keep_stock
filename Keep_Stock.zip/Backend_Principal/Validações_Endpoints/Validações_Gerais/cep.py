import urllib.parse
import requests

token = "22472|U4FnUbPngllkqZz2ZY5ytMlZOjxrtu7i"

def validar_cep(cep, token):
    url = f"https://api.invertexto.com/v1/cep/{cep}"
    params = {"token": token}
    resposta = requests.get(url, params=params).json()
    return resposta

if __name__ == "__main__":
    cep = "71205060"
    token = "22472|U4FnUbPngllkqZz2ZY5ytMlZOjxrtu7i"

    resultado = validar_cep(cep, token)

    if resultado:
        print("Resposta da API:")
        print(resultado)
    else:
        print("Não foi possível validar o CEP.")