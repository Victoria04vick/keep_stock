import urllib.parse
import requests

def validar_nome(dados_usuario):
    if len(dados_usuario["nome"]) > 0:
        if len(dados_usuario["nome"]) < 120:
            return True
        return False
    
    