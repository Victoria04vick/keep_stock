Users = [
    {"nome":"Allysson", "senha":"1234"},
    {"nome":"Murylo", "senha":"bigboss"},
    {"nome":"Victoria", "senha":"6789"},
    {"nome":"Pietro", "senha":"6284"},
    {"nome":"Eliara", "senha":"2602"}
]

def valida_login(dado):
    for usuário in Users:
        if usuário["nome"] == dado["nome"] and usuário["senha"] == dado["senha"]:
                return True
    return False
