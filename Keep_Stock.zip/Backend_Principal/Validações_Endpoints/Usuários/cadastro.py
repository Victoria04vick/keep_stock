import urllib.parse
import requests

def validar_cpf(cpf, token):
    # URL base da API
    url = "https://api.invertexto.com/v1/validator"

    # Parametros que serão enviados via query
    params = {
        "token": token,
        "value" : cpf
    }

    try:
    # Envia a requisição GET com os parâmetros
        response = requests.get(url, params=params)
        response.raise_for_status()

        # Converte a resposta para json
        data = response.json()
        return data
    
    except requests.exceptions.HTTPError as errh:
        print("Erro HTTP:", errh)
    except requests.exceptions.ConnectionError as errc:
        print("Erro de conexão:", errc)
    except requests.exceptions.Timeout as erry:
        print("Timeout:", erry)

    return None


def validar_email(email, token):
    base_url = "https://api.invertexto.com/v1/email-validator"

    # Codifica o e-mail para garantir que a URL fique correta
    email_encoded = urllib.parse.quote(email)

    # Monta a URL com o e-mail na rota
    url = f"{base_url}/{email_encoded}"

    # Parametros da query string (neste caso, apenas o token)
    params = {"token": token}

    try:
        # Realiz a requisição GET passando os parametros na URL
        response = requests.get(url, params=params)
        response.raise_for_status() # Levanta exceção para status HTTP de erro

        # Converte a respost para JSON
        data = response.json()

        return data
    
    except requests.exceptions.HTTPError as errh:
        print("Erro HTTP:", errh)
    except requests.exceptions.ConnectionError as errc:
        print("Erro de conexão:", errc)
    except requests.exceptions.Timeout as errt:
        print("Timeout:", errt)
    except requests.exceptions.RequestException as err:
        print("Erro:", err)

    return None

def validar_nome_usuario(dados_usuario):
    if len(dados_usuario["nome"]) > 0:
        if len(dados_usuario["nome"]) < 120:
            return True
        return False
    
def validar_senha(dados_usuario):
    if len(dados_usuario["senha"]) > 0:
        if len(dados_usuario["senha"]) < 20:
            return True
        return False

def confirmar_senha(dados_usuario):
    return dados_usuario["senha"] == dados_usuario["confirmar_senha"]


if __name__ == "__main__":
    cpf = "49747663848"
    token = "22472|U4FnUbPngllkqZz2ZY5ytMlZOjxrtu7i"
    email = "allysson.santos1717@gmail.com"

    resultado = validar_cpf(cpf, token)

    if resultado:
        print("Resposta da API:")
        print(resultado)
    else:
        print("Não foi possível validar o CPF.")

    resultado = validar_email(email, token)

    if resultado:
        print("Resposta da API:")
        print(resultado)

    else:
        print("Não foi possível validar o e-mail.")