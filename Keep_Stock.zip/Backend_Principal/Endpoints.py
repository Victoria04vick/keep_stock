from flask import Flask, request, jsonify
from validações.Validações_Gerais.cep import validar_cep
from validações.Validações_Gerais.cpf import validar_cpf
from validações.Validações_Gerais.cnpj import validar_cnpj
from validações.Validações_Gerais.email import validar_email
from validações.Validações_Gerais.tamanho_nome import validar_nome
from validações.Usuários.login import valida_login
from validações.Usuários.cadastro import validar_senha
from validações.Usuários.cadastro import confirmar_senha


   
app = Flask(__name__)

def validar_exemplo(dado):
    return True if dado else False

# SIMULAÇÃO DE DADOS

Cliente = [
    {"teste":"teste"}
]

Funcionários = [
    {"email": "allysson@email.com", "senha": "123456", "nome": "Allysson", "funções": ["Administrador"]},
    {"email": "Murylo@email.com", "senha": "abcdef", "nome": "Murylo", "funções": ["Operador"]}
]

Medicamentos = [
    {"id": 1, "nome": "Dipirona", "codigo": "001", "quantidade": 100, "lote": "1234", "validade": "2026-05-01", "tarja": "Isento"},
    {"id": 2, "nome": "Clonazepam", "codigo": "002", "quantidade": 20, "lote": "5678", "validade": "2025-11-10", "tarja": "Tarja Preta"}
]

Receitas = [
    {
        "id": 1,
        "medicamento": "Clonazepam 2mg",
        "crm_medico": "123456-SP",
        "data": "2025-09-15",
        "observacao": "Uso controlado, 1 comprimido ao dia."
    }]

Fornecedores = [
    {"id": 1, "nome": "Farmac Distribuidora", "cnpj": "12.345.678/0001-99", "contato": "farmac@email.com", "telefone": "(11)99999-0000"},
    {"id": 2, "nome": "Saude Mais LTDA", "cnpj": "98.765.432/0001-11", "contato": "saude@email.com", "telefone": "(11)98888-1111"}
]

Produtos = [
    {"Remédio": "Dipirona", "Código": "1", "quantidade": 100},
    {"Remédio": "Dorflex", "Código": "2", "quantidade": 50}
]

Empilhadeiras = [
    {"modelo": "modelo01", "código": "1", "operador": "Murylo"},
    {"modelo": "modelo02", "código": "2", "operador": "Victória"}
]

Relatório = [
    {"Código": "1", "Descrição": "teste1"},
    {"Código": "2", "Descrição": "teste2"}
]

Pedidos = [
    {"Código do Pedido": "1", "itens": "etc..."},
    {"Código do Pedido": "2", "itens": "etc..."}
]

Entregas = [
    {"codigo_pedido": "1", "status": "Em separação"},
    {"codigo_pedido": "2", "status": "Em transporte"}
]

Historico_Movimentacao = [
    {"Teste": "Teste1"}
]

Notas_Fiscais = [
    {"Teste": "Teste2"}
]

Distribuidoras = []

Câmaras_frias = []

# ADENDOS
# indice em algumas funções significa o número de id do produto, por isso o f strings em alguns returns
# Alguns gets precisa colocar para ler algúm dicionário, se não, não funciona

# HOME
@app.route("/")
def Home():
    return 'Home de Endpoints da KeepStock'


# FUNCIONÁRIOS (login, cadastro)

# CADASTRO

@app.route('/Cadastro', methods=['GET', 'POST'])
def Cadastro():
    if request.method == 'GET':
        return jsonify(Funcionários)
    
    elif request.method == 'POST':
        dado = request.get_json()

        token = "22472|U4FnUbPngllkqZz2ZY5ytMlZOjxrtu7i"

        resultado_cpf = validar_cpf(dado["cpf"], token)
        if not resultado_cpf or not resultado_cpf.get("valid"):
            return {"valida": False, "Mensagem": "CPF inválido"}

        resultado_email = validar_email(dado["email"], token)
        if not resultado_email or not resultado_email.get("valid_format") or not resultado_email.get("valid_mx") or resultado_email.get("disposable") is True:
            return {"valida": False, "Mensagem": "E-mail inválido"}

        if not validar_nome(dado):
            return {"valida": False, "Mensagem": "Nome inválido"}

        if not validar_senha(dado):
            return {"valida": False, "Mensagem": "Senha inválida"}

        if not confirmar_senha(dado):
            return {"valida": False, "Mensagem": "As senhas não coincidem"}
        return {"valida": True, "Mensagem": "Funcionário cadastrado com sucesso!"}
        

    
# HISTÓRICO DE CADASTROS

@app.route("/Histórico_Cadastros", methods=["GET"])
def historico_cadastros ():
    resultado = validar_exemplo()
    if resultado == True:
        return {"valida": True, "Mensagem": "Histórico de cadastros enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar histórico de cadastros."}

# LOGIN

@app.route("/Funcionários/<int:indice>", methods=["GET"])
def Buscar_Funcionário(indice):
    if indice < len(Funcionários):
        return jsonify(Funcionários[indice])
    return jsonify({"erro": "Funcionário não encontrado"}), 404


@app.route('/Login', methods=['POST'])
def Login_Usuario():
    dados = request.get_json()
    resultado = valida_login(dados)
    if resultado == True:
        return {"valida": True, "Mensagem": "Login realizado com sucesso!"}
    return {"valida": False, "Mensagem": "Email ou senha inválidos."}

@app.route("/Atualizar_Funcionario/<int:indice>", methods=["PUT"])
def atualizar_funcionario(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Funcionário atualizado com sucesso!"}
    return {"valida": False, "Mensagem": "Funcionário não encontrado."}


@app.route("/Deletar_Funcionario/<int:indice>", methods=["DELETE"])
def deletar_funcionario(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Funcionário removido com sucesso!"}
    return {"valida": False, "Mensagem": "Funcionário não encontrado."}

# HISTÓRICO DE LOGINS

@app.route("/Histórico/Login", methods=["GET"])
def auditoria_login():
    resultado = validar_exemplo()
    if resultado == True:
        return {"valida": True, "Mensagem": "Logins recentes enviados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar auditoria de logins."}

#  CLIENTES

@app.route('/Cliente_Físico', methods=['GET', 'POST'])
def Gerenciar_Clientes_Fisico():
    if request.method == 'GET':
        return jsonify(Cliente)
    
    elif request.method == 'POST':
        dado = request.get_json()

        token = "22472|U4FnUbPngllkqZz2ZY5ytMlZOjxrtu7i"

        resultado_cpf = validar_cpf(dado["cpf"], token)
        if not resultado_cpf or not resultado_cpf.get("valid"):
            return {"valida": False, "Mensagem": "CPF inválido"}

        resultado_email = validar_email(dado["email"], token)
        if not resultado_email or not resultado_email.get("valid_format") or not resultado_email.get("valid_mx") or resultado_email.get("disposable") is True:
            return {"valida": False, "Mensagem": "E-mail inválido"}

        if not validar_nome(dado):
            return {"valida": False, "Mensagem": "Nome inválido"}
        cep = dado.get("cep")

        if not cep or cep == None:
            return jsonify({"erro": "Informe o campo cep"}), 400
        if len(cep) != 8 or not cep.isdigit():
            return jsonify({"erro": "CEP inválido. Deve conter 8 números."}), 400

        try:
            resposta = validar_cep(dado["cep"], token)
            resposta_state = resposta["state"]
            resposta_city = resposta["city"]
            resposta_neighborhood = resposta["neighborhood"]
            resposta_street = resposta["street"]
            return jsonify({
            #    "cep": cep,
            #    "city": resposta.get("city"),
            #   "state": resposta.get("state"),
            #    "neighborhood": resposta.get("neighborhood"),
            #    "street": resposta.get("street"),
            #   "complement": resposta.get("complement"),
            #    "ibge": resposta.get("ibge"),
            #    "mensagem": "CEP validado com sucesso!"
                "Mensagem" : "Cliente físico cadastrado com sucesso",
                "Localização" : f"País: {resposta_state}, Cidade: {resposta_city}, Bairro: {resposta_neighborhood}, Rua: {resposta_street}"
            })
        except Exception as e:
            return jsonify({"erro": "Erro ao validar CEP", "detalhe": str(e)}), 500
    
@app.route('/Cliente_Jurídico', methods=['GET', 'POST'])
def Gerenciar_Clientes_Juridico():
    if request.method == 'GET':
        return jsonify(Cliente)
    
    elif request.method == 'POST':
        dado = request.get_json()

        token = "22472|U4FnUbPngllkqZz2ZY5ytMlZOjxrtu7i"

        resultado_cnpj = validar_cnpj(dado["cnpj"], token)
        if not resultado_cnpj or not resultado_cnpj.get("valid"):
            return {"valida": False, "Mensagem": "CNPJ inválido"}

        resultado_email = validar_email(dado["email"], token)
        if not resultado_email or not resultado_email.get("valid_format") or not resultado_email.get("valid_mx") or resultado_email.get("disposable") is True:
            return {"valida": False, "Mensagem": "E-mail inválido"}

        if not validar_nome(dado):
            return {"valida": False, "Mensagem": "Nome inválido"}
        
        cep = dado.get("cep")

        if not cep or cep == None:
            return jsonify({"erro": "Informe o campo cep"}), 400
        if len(cep) != 8 or not cep.isdigit():
            return jsonify({"erro": "CEP inválido. Deve conter 8 números."}), 400

        try:
            resposta = validar_cep(dado["cep"], token)
            resposta_state = resposta["state"]
            resposta_city = resposta["city"]
            resposta_neighborhood = resposta["neighborhood"]
            resposta_street = resposta["street"]
            return jsonify({
            #    "cep": cep,
            #    "city": resposta.get("city"),
            #   "state": resposta.get("state"),
            #    "neighborhood": resposta.get("neighborhood"),
            #    "street": resposta.get("street"),
            #   "complement": resposta.get("complement"),
            #    "ibge": resposta.get("ibge"),
            #    "mensagem": "CEP validado com sucesso!"
                "Mensagem" : "Cliente jurídico cadastrado com sucesso",
                "Localização" : f"País: {resposta_state}, Cidade: {resposta_city}, Bairro: {resposta_neighborhood}, Rua: {resposta_street}"
            })
        except Exception as e:
            return jsonify({"erro": "Erro ao validar CEP", "detalhe": str(e)}), 500


@app.route("/Cliente/<int:indice>", methods=["GET", "PUT", "DELETE"])
def cliente_pesquisar(indice):
    if request.method == 'GET':
        if indice < len(Cliente):
            return jsonify(Cliente[indice])
        return jsonify({"erro": "Cliente não encontrada"}), 404

    elif request.method == 'PUT':
        dado = request.get_json()
        resultado = validar_exemplo(dado)
        if resultado == True:
            return {"valida": True, "Mensagem": "Cliente atualizada com sucesso!"}
        return {"valida": False, "Mensagem": "Erro ao atualizar cliente."}

    elif request.method == 'DELETE':
        dado = request.get_json()
        resultado = validar_exemplo(dado)
        if resultado == True:
            return {"valida": True, "Mensagem": "Cliente removido com sucesso!"}
        return {"valida": False, "Mensagem": "Erro ao remover cliente."}
    
# PRODUTOS 

@app.route("/Buscar_Produto", methods=["GET"])
def buscar_produto():
    return jsonify(Produtos)


@app.route('/Produtos/<int:id>', methods=['GET', 'PUT'])
def remedios_detalhes(id):
    if request.method == 'GET':
        if id < len(Produtos):
            return jsonify(Produtos[id])
        else:
            return jsonify({"erro": "Produto não encontrado"}), 404

    elif request.method == 'PUT':
        dado = request.get_json()
        resultado = validar_exemplo(dado)
        if resultado == True:
            return {"valida": True, "Mensagem": "Produto atualizado com sucesso!"}
        return {"valida": False, "Mensagem": "Produto não encontrado."}


@app.route('/Produto_Saída/<int:id>', methods=['POST'])
def saida_produtos(id):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Saída de produto registrada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao registrar saída de produto."}


@app.route("/Produtos_Estoque", methods=["GET", "POST"])
def produtos_estoque():
    if request.method == 'GET':
        return jsonify(Produtos)
    elif request.method == 'POST':
        dado = request.get_json()
        resultado = validar_exemplo(dado)
        if resultado == True:
            return {"valida": True, "Mensagem": "Produto adicionado ao estoque com sucesso!"}
        return {"valida": False, "Mensagem": "Erro ao adicionar produto ao estoque."}


@app.route("/Produtos_Estoque/<int:indice>", methods=["GET", "PUT", "DELETE"])
def produto_estoque_detalhe(indice):
    if request.method == 'GET':
        if indice < len(Produtos):
            return jsonify(Produtos[indice])
        return jsonify({"erro": "Produto não encontrado"}), 404

    elif request.method == 'PUT':
        dado = request.get_json()
        resultado = validar_exemplo(dado)
        if resultado == True:
            return {"valida": True, "Mensagem": "Produto atualizado com sucesso!"}
        return {"valida": False, "Mensagem": "Produto não encontrado."}

    elif request.method == 'DELETE':
        dado = request.get_json()
        resultado = validar_exemplo(dado)
        if resultado == True:
            return {"valida": True, "Mensagem": "Produto removido com sucesso!"}
        return {"valida": False, "Mensagem": "Produto não encontrado."}

# HISTÓRICO ALTERAÇÕES DE PRODUTOS

@app.route("/Historico/Produtos", methods=["GET"])
def listar_historico_produtos():
    resultado = validar_exemplo()
    if resultado == True:
        return {"valida": True, "Mensagem": "Histórico de alterações de produtos enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar histórico de produtos."}

@app.route("/Historico/Produtos/<int:indice>", methods=["GET"])
def detalhar_historico_produto(indice):
    resultado = validar_exemplo()
    if resultado == True:
        return {"valida": True, "Mensagem": f"Histórico detalhado do produto {indice} enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao buscar histórico do produto."}


@app.route("/Movimentar_Estoque", methods=["POST"])
def movimentar_estoque():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Movimentação de estoque registrada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro na movimentação de estoque."}


@app.route("/Ajuste_Quantidade/<int:indice>", methods=["PUT"])
def ajuste_quantidade(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Quantidade ajustada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao ajustar quantidade."}


#  EMPILHADEIRAS 

@app.route('/Empilhadeiras', methods=['GET', 'POST'])
def Gerenciar_Empilhadeiras():
    if request.method == 'GET':
        return jsonify(Empilhadeiras)
    elif request.method == 'POST':
        dado = request.get_json()
        resultado = validar_exemplo(dado)
        if resultado == True:
            return {"valida": True, "Mensagem": "Empilhadeira adicionada com sucesso!"}
        return {"valida": False, "Mensagem": "Erro ao adicionar empilhadeira."}


@app.route("/Empilhadeiras/<int:indice>", methods=["GET", "PUT", "DELETE"])
def empilhadeira_detalhe(indice):
    if request.method == 'GET':
        if indice < len(Empilhadeiras):
            return jsonify(Empilhadeiras[indice])
        return jsonify({"erro": "Empilhadeira não encontrada"}), 404

    elif request.method == 'PUT':
        dado = request.get_json()
        resultado = validar_exemplo(dado)
        if resultado == True:
            return {"valida": True, "Mensagem": "Empilhadeira atualizada com sucesso!"}
        return {"valida": False, "Mensagem": "Erro ao atualizar empilhadeira."}

    elif request.method == 'DELETE':
        dado = request.get_json()
        resultado = validar_exemplo(dado)
        if resultado == True:
            return {"valida": True, "Mensagem": "Empilhadeira removida com sucesso!"}
        return {"valida": False, "Mensagem": "Erro ao remover empilhadeira."}
    
# RELATÓRIOS DE EMPILHADEIRAS (ativas, inativas, em manutenção, em utilização )
    

#  PEDIDOS 

@app.route("/Pedidos", methods=["GET"])
def listar_pedidos():
    return jsonify(Pedidos)


@app.route("/Pedido", methods=["POST"])
def adicionar_pedido():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Pedido adicionado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao adicionar pedido."}


@app.route("/Pedido/<int:indice>", methods=["GET", "PUT", "DELETE"])
def pedido_detalhe(indice):
    if request.method == 'GET':
        if indice < len(Pedidos):
            return jsonify(Pedidos[indice])
        return jsonify({"erro": "Pedido não encontrado"}), 404

    elif request.method == 'PUT':
        dado = request.get_json()
        resultado = validar_exemplo(dado)
        if resultado == True:
            return {"valida": True, "Mensagem": "Pedido atualizado com sucesso!"}
        return {"valida": False, "Mensagem": "Erro ao atualizar pedido."}

    elif request.method == 'DELETE':
        dado = request.get_json()
        resultado = validar_exemplo(dado)
        if resultado == True:
            return {"valida": True, "Mensagem": "Pedido removido com sucesso!"}
        return {"valida": False, "Mensagem": "Erro ao remover pedido."}


#  FORNECEDORES 

@app.route("/Fornecedores", methods=["GET", "POST"])
def fornecedores():
    if request.method == 'GET':
        return jsonify(Fornecedores)
    elif request.method == 'POST':
        dado = request.get_json()

        token = "22472|U4FnUbPngllkqZz2ZY5ytMlZOjxrtu7i"

        resultado_cnpj = validar_cnpj(dado["cnpj"], token)
        if not resultado_cnpj or not resultado_cnpj.get("valid"):
            return {"valida": False, "Mensagem": "CNPJ inválido"}

        resultado_email = validar_email(dado["email"], token)
        if not resultado_email or not resultado_email.get("valid_format") or not resultado_email.get("valid_mx") or resultado_email.get("disposable") is True:
            return {"valida": False, "Mensagem": "E-mail inválido"}

        if not validar_nome(dado):
            return {"valida": False, "Mensagem": "Nome inválido"}
        
        cep = dado.get("cep")

        if not cep or cep == None:
            return jsonify({"erro": "Informe o campo cep"}), 400
        if len(cep) != 8 or not cep.isdigit():
            return jsonify({"erro": "CEP inválido. Deve conter 8 números."}), 400

        try:
            resposta = validar_cep(dado["cep"], token)
            resposta_state = resposta["state"]
            resposta_city = resposta["city"]
            resposta_neighborhood = resposta["neighborhood"]
            resposta_street = resposta["street"]
            return jsonify({
            #    "cep": cep,
            #    "city": resposta.get("city"),
            #   "state": resposta.get("state"),
            #    "neighborhood": resposta.get("neighborhood"),
            #    "street": resposta.get("street"),
            #   "complement": resposta.get("complement"),
            #    "ibge": resposta.get("ibge"),
            #    "mensagem": "CEP validado com sucesso!"
                "Mensagem" : "Fornecedor cadastrado com sucesso",
                "Localização" : f"País: {resposta_state}, Cidade: {resposta_city}, Bairro: {resposta_neighborhood}, Rua: {resposta_street}"
            })
        except Exception as e:
            return jsonify({"erro": "Erro ao validar CEP", "detalhe": str(e)}), 500



@app.route("/Fornecedores/<int:indice>", methods=["GET", "PUT", "DELETE"])
def fornecedor_detalhe(indice):
    if request.method == 'GET':
        if indice < len(Fornecedores):
            return jsonify(Fornecedores[indice])
        return jsonify({"erro": "Fornecedor não encontrado"}), 404

    elif request.method == 'PUT':
        dado = request.get_json()
        resultado = validar_exemplo(dado)
        if resultado == True:
            return {"valida": True, "Mensagem": "Fornecedor atualizado com sucesso!"}
        return {"valida": False, "Mensagem": "Erro ao atualizar fornecedor."}

    elif request.method == 'DELETE':
        dado = request.get_json()
        resultado = validar_exemplo(dado)
        if resultado == True:
            return {"valida": True, "Mensagem": "Fornecedor removido com sucesso!"}
        return {"valida": False, "Mensagem": "Erro ao remover fornecedor."}
    
# FORNECEDORES - CONTATO

@app.route("/Fornecedores_Contato/<int:indice>", methods=["GET"])
def buscar_contato_fornecedor(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Contato do fornecedor {indice} enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao buscar contato do fornecedor."}

@app.route("/Fornecedores/Contato/<int:indice>", methods=["PUT"])
def atualizar_contato_fornecedor(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Contato do fornecedor {indice} atualizado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao atualizar contato do fornecedor."}

# FORNECEDORES - OUTROS DADOS (necessidade de reposição de estoque, histórico de fornecimento por fornecedor, avaliação de qualidade do forncedor)

@app.route("/Fornecedores/Repor_Estoque/<int:produto_id>", methods=["POST"])
def pedido_reposicao(produto_id):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Pedido de reposição para produto {produto_id} enviado ao fornecedor com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao enviar pedido de reposição."}

@app.route("/Fornecedores/Historico/<int:indice>", methods=["GET"])
def historico_fornecedor(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Histórico de fornecimento do fornecedor {indice} enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao buscar histórico do fornecedor."}

@app.route("/Fornecedores/Avaliação/<int:indice>", methods=["POST"])
def avaliar_fornecedor(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Fornecedor {indice} avaliado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao avaliar fornecedor."}

# CONTROLE DE FORNECEDORES POR REGIÃO

@app.route("/Fornecedores/Regiao/<string:regiao>", methods=["GET"])
def listar_fornecedores_regiao(regiao):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Fornecedores da região {regiao} listados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar fornecedores por região."}

@app.route("/Fornecedores/Regiao/<string:regiao>", methods=["POST"])
def adicionar_fornecedor_regiao(regiao):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Fornecedor adicionado na região {regiao} com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao adicionar fornecedor na região."}

#  NOTAS FISCAIS 

@app.route("/Entrada_NF", methods=["GET", "POST"])
def notas_fiscais():
    if request.method == 'GET':
        return jsonify(Notas_Fiscais)
    elif request.method == 'POST':
        dado = request.get_json()
        resultado = validar_exemplo(dado)
        if resultado == True:
            return {"valida": True, "Mensagem": "Nota fiscal registrada com sucesso!"}
        return {"valida": False, "Mensagem": "Erro ao registrar nota fiscal."}
    
# RELATÓRIO DE NOTAS FISCAIS

@app.route("/Relatorios/Notas_Ficais", methods=["GET"])
def relatorio_entrada_produtos():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Relatório de notas fiscais enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar relatório de nots fiscaais"}


#  RASTREAMENTO DE ENTREGAS 

@app.route("/Pedidos_Entrega_Status/<codigo_pedido>", methods=["GET", "PUT"])
def rastreamento_entrega(codigo_pedido):
    if request.method == 'GET':
        for entrega in Entregas:
            if entrega["codigo_pedido"] == codigo_pedido:
                return jsonify(entrega)
        return jsonify({"erro": "Entrega não encontrada"}), 404

    elif request.method == 'PUT':
        dado = request.get_json()
        resultado = validar_exemplo(dado)
        if resultado == True:
            return {"valida": True, "Mensagem": "Status da entrega atualizado com sucesso!"}
        return {"valida": False, "Mensagem": "Erro ao atualizar status da entrega."}
    
# PRODUTOS EM TRANSITO

@app.route("/Produtos_Transito", methods=["GET"])
def listar_produtos_transito():
    return {"valida": True, "Mensagem": "Lista de produtos em trânsito enviada com sucesso!"}

@app.route("/Produtos_Transito/Registrar", methods=["POST"])
def registrar_produto_transito():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Produto em trânsito registrado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao registrar produto em trânsito."}

@app.route("/Produtos_Transito/<int:indice>", methods=["PUT"])
def atualizar_produto_transito(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Produto em trânsito {indice} atualizado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao atualizar produto em trânsito."}

@app.route("/Produtos_Transito/<int:indice>", methods=["DELETE"])
def deletar_produto_transito(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Produto em trânsito {indice} removido com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao remover produto em trânsito."}


# MEDICAMENTOS CONTROLADOS 

@app.route("/Medicamentos/Registrar_Receita", methods=["POST"])
def registrar_receita():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Receita registrada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao registrar receita."}


@app.route("/Medicamentos/Receitas", methods=["GET"])
def listar_receitas():
    return jsonify(Receitas)

# MEDICAMENTOS CONTROLADOS - ALERTAS

@app.route("/Medicamentos/Controlados/Alertas", methods=["GET"])
def alertas_medicamentos_controlados():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Alertas de medicamentos controlados enviados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar alertas de medicamentos controlados."}

@app.route("/Medicamentos/Controlados/Registrar_Alerta", methods=["POST"])
def registrar_alerta_medicamento_controlado():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Alerta de medicamento controlado registrado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao registrar alerta de medicamento controlado."}

# ALERTAS DE ESTOQUE

@app.route("/Alertas_Estoque", methods=["GET"])
def listar_alertas_estoque():
    return {"valida": True, "Mensagem": "Lista de alertas de estoque enviada com sucesso!"}

@app.route("/Alertas_Estoque", methods=["POST"])
def criar_alerta_estoque():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Alerta de estoque registrado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao registrar alerta de estoque."}

@app.route("/Alertas_Estoque/<int:indice>", methods=["PUT"])
def atualizar_alerta_estoque(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Alerta de estoque {indice} atualizado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao atualizar alerta de estoque."}

@app.route("/Alertas_Estoque/<int:indice>", methods=["DELETE"])
def deletar_alerta_estoque(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Alerta de estoque {indice} removido com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao remover alerta de estoque."}

# CONTROLE DE ESTOQUE POR TEMPERATURA (câmaras frias, temperatura controlada, etc...)

@app.route("/Temperatura_Controlada", methods=["GET"])
def listar_temperaturas_estoque():
    return {"valida": True, "Mensagem": "Lista de temperaturas reguladas do estoque enviada com sucesso!"}

@app.route("/Temperatura_Controlada", methods=["POST"])
def adicionar_temperatura_controlada():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Temperatura controlada adicionada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao registar temperatura controlada do estoque."}

@app.route("/Temperatura_Controlada/<int:indice>", methods=["PUT"])
def atualizar_temperatura_controlada(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Temperatura controlada {indice} atualizada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao atualizar temperatura controlada."}

@app.route("/Temperatura_Controlada/<int:indice>", methods=["DELETE"])
def deletar_temperatura_controlada(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Temperatura controlada {indice} removido com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao remover temperatura controlada."}

# LISTAGEM DE VENCIMENTOS

@app.route("/Vencimentos_Produtos", methods=["GET"])
def listar_vencimentos_produtos():
    return {"valida": True, "Mensagem": "Lista de vencimentos de produtos enviada com sucesso!"}

@app.route("/Vencimentos_Produtos", methods=["POST"])
def registrar_vencimento_produtos():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Vencimento de produto registrado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao registrar vencimento de produto."}

@app.route("/Vencimentos_Produtos/<int:indice>", methods=["PUT"])
def atualizar_vencimento_produtos(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Vencimento de produto {indice} atualizado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao atualizar vencimento de produto."}

@app.route("/Vencimentos_Produtos/<int:indice>", methods=["DELETE"])
def deletar_vencimento_produtos(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Vencimento de produto {indice} removido com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao remover vencimento de produto."}

# PRODUTOS EXPIRADOS

@app.route("/Produtos_Expirados", methods=["GET"])
def listar_produtos_expirados():
    return {"valida": True, "Mensagem": "Lista de produtos expirados enviada com sucesso!"}

@app.route("/Produtos_Expirados/Registrar", methods=["POST"])
def registrar_produto_expirado():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Produto expirado registrado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao registrar produto expirado."}

# AJUSTES DE ESTOQUE

@app.route("/Estoque_Ajustes", methods=["GET"])
def listar_ajustes_estoque():
    return {"valida": True, "Mensagem": "Lista de ajustes de estoque enviada com sucesso!"}

@app.route("/Estoque_Ajustes", methods=["POST"])
def criar_ajuste_estoque():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Ajuste de estoque registrado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao registrar ajuste de estoque."}

@app.route("/Estoque_Ajustes/<int:indice>", methods=["PUT"])
def atualizar_ajuste_estoque(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Ajuste de estoque {indice} atualizado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao atualizar ajuste de estoque."}

@app.route("/Estoque_Ajustes/<int:indice>", methods=["DELETE"])
def deletar_ajuste_estoque(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Ajuste de estoque {indice} removido com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao remover ajuste de estoque."}

# HISTÓRICO DE MUDANÇAS FÍSICAS DE ESTOQUE

@app.route("/Logs_Estoque", methods=["GET"])
def listar_logs_estoque():
    return {"valida": True, "Mensagem": "Logs de estoque enviados com sucesso!"}

@app.route("/Logs_Estoque", methods=["POST"])
def registrar_log_estoque():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Log de estoque registrado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao registrar log de estoque."}

# TRANSPORTE DE PRODUTOS

@app.route("/Transporte_Produtos", methods=["GET"])
def listar_transporte_produtos():
    return {"valida": True, "Mensagem": "Lista de transporte de produtos enviada com sucesso!"}

@app.route("/Transporte_Produtos", methods=["POST"])
def registrar_transporte_produtos():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Transporte de produto registrado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao registrar transporte de produto."}

@app.route("/Transporte_Produtos/<int:indice>", methods=["PUT"])
def atualizar_transporte_produtos(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Transporte de produto {indice} atualizado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao atualizar transporte de produto."}

@app.route("/Transporte_Produtos/<int:indice>", methods=["DELETE"])
def deletar_transporte_produtos(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Transporte de produto {indice} removido com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao remover transporte de produto."}

# RASTREAMENTO DE ENCOMENDAS

@app.route("/Rastreamento_Encomendas", methods=["GET"])
def listar_rastreamento_encomendas():
    return {"valida": True, "Mensagem": "Lista de rastreamento de encomendas enviada com sucesso!"}

@app.route("/Rastreamento_Encomendas", methods=["POST"])
def registrar_rastreamento_encomendas():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Rastreamento de encomenda registrado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao registrar rastreamento de encomenda."}

@app.route("/Rastreamento_Encomendas/<int:indice>", methods=["PUT"])
def atualizar_rastreamento_encomendas(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Rastreamento de encomenda {indice} atualizado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao atualizar rastreamento de encomenda."}

@app.route("/Rastreamento_Encomendas/<int:indice>", methods=["DELETE"])
def deletar_rastreamento_encomendas(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Rastreamento de encomenda {indice} removido com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao remover rastreamento de encomenda."}

# TRANSPORTADORAS

@app.route("/Transportadoras", methods=["GET"])
def listar_transportadoras():
    return {"valida": True, "Mensagem": "Lista de transportadoras enviada com sucesso!"}

@app.route("/Transportadoras", methods=["POST"])
def adicionar_transportadora():
    dado = request.get_json()

    token = "22472|U4FnUbPngllkqZz2ZY5ytMlZOjxrtu7i"

    resultado_cnpj = validar_cnpj(dado["cnpj"], token)
    if not resultado_cnpj or not resultado_cnpj.get("valid"):
        return {"valida": False, "Mensagem": "CNPJ inválido"}

    resultado_email = validar_email(dado["email"], token)
    if not resultado_email or not resultado_email.get("valid_format") or not resultado_email.get("valid_mx") or resultado_email.get("disposable") is True:
        return {"valida": False, "Mensagem": "E-mail inválido"}

    if not validar_nome(dado):
        return {"valida": False, "Mensagem": "Nome inválido"}
        
    cep = dado.get("cep")

    if not cep or cep == None:
        return jsonify({"erro": "Informe o campo cep"}), 400
    if len(cep) != 8 or not cep.isdigit():
        return jsonify({"erro": "CEP inválido. Deve conter 8 números."}), 400

    try:
            resposta = validar_cep(dado["cep"], token)
            resposta_state = resposta["state"]
            resposta_city = resposta["city"]
            resposta_neighborhood = resposta["neighborhood"]
            resposta_street = resposta["street"]
            return jsonify({
            #    "cep": cep,
            #    "city": resposta.get("city"),
            #   "state": resposta.get("state"),
            #    "neighborhood": resposta.get("neighborhood"),
            #    "street": resposta.get("street"),
            #   "complement": resposta.get("complement"),
            #    "ibge": resposta.get("ibge"),
            #    "mensagem": "CEP validado com sucesso!"
                "Mensagem" : "Distribuidor cadastrado com sucesso",
                "Localização" : f"País: {resposta_state}, Cidade: {resposta_city}, Bairro: {resposta_neighborhood}, Rua: {resposta_street}"
        })
    except Exception as e:
        return jsonify({"erro": "Erro ao validar CEP", "detalhe": str(e)}), 500

@app.route("/Transportadoras/<int:indice>", methods=["PUT"])
def atualizar_transportadora(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Transportadora {indice} atualizada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao atualizar transportadora."}

@app.route("/Transportadoras/<int:indice>", methods=["DELETE"])
def deletar_transportadora(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Transportadora {indice} removida com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao remover transportadora."}

# TRANSPORTADORES - AVANÇDO (agendamento de transporte, eficiência de logística - se está entregando certo, no tempo certo, sem erros, etc...)

@app.route("/Transporte/Agendar", methods=["POST"])
def agendar_transporte():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Transporte agendado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao agendar transporte."}

@app.route("/Relatorios/Logistica/Eficiencia", methods=["GET"])
def relatorio_eficiencia_logistica():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Relatório de eficiência logística enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar relatório de eficiência logística."}

# RASTREAMENTO FÍSICO DE LOTES (faz sentido?)

@app.route("/Lotes_Produtos", methods=["GET"])
def listar_lotes_produtos():
    return {"valida": True, "Mensagem": "Lista de lotes de produtos enviada com sucesso!"}

@app.route("/Lotes_Produtos", methods=["POST"])
def registrar_lote_produtos():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Lote de produto registrado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao registrar lote de produto."}

@app.route("/Lotes_Produtos/<int:indice>", methods=["PUT"])
def atualizar_lote_produtos(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Lote de produto {indice} atualizado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao atualizar lote de produto."}

@app.route("/Lotes_Produtos/<int:indice>", methods=["DELETE"])
def deletar_lote_produtos(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Lote de produto {indice} removido com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao remover lote de produto."}

# RELATÓRIOS DE REGULAMENTAÇÃO E CONFORMIDADE

@app.route("/Relatorios_Regulamentacao", methods=["GET"])
def listar_relatorios_regulamentacao():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Relatórios de regulamentação enviados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar relatórios de regulamentação."}

# RELATÓRIOS DE PRESCRIÇÃO DIGITAL

@app.route("/Relatorios_Prescrição", methods=["GET"])
def listar_relatorios_prescicao():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Relatórios de prescrição digital enviados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar relatórios de prescrição digital."}

# RELATÓRIOS FINANCEIROS

@app.route("/Relatorios/Financeiros", methods=["GET"])
def listar_relatorios_financeiros():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Relatórios financeiros enviados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar relatórios financeiros."}

@app.route("/Relatorios/Financeiros/<int:indice>", methods=["GET"])
def visualizar_relatorio_financeiro(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Relatório financeiro {indice} enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao buscar relatório financeiro."}

# RELATÓRIOS FINANCEIROS - AVANÇADOS (lucro, perda, analise, projeção, custo)

@app.route("/Relatorios/Financeiros/Lucratividade_Produto", methods=["GET"])
def relatorio_lucro_produto():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Relatório de lucratividade por produto enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar relatório de lucratividade por produto."}

@app.route("/Relatorios/Perdas", methods=["GET"])
def relatorio_perdas():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Relatório de perdas de produtos enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar relatório de perdas de produtos."}

@app.route("/Relatorios/Vendas/Analise", methods=["GET"])
def relatorio_analise_vendas():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Relatório de vendas por região / categoria enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar relatório de vendas por região / categoria."}

@app.route("/Relatorios/Estoque/Projecao", methods=["GET"])
def relatorio_projecao_estoque():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Projeção de estoque futuro enviada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar projeção de estoque futuro."}

@app.route("/Relatorios/Estoque/Custo", methods=["GET"])
def relatorio_custo_estoque():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Custo do estoque enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar relatório de custo do estoque."}

# RELATÓRIOS DE VENDAS

@app.route("/Relatorios/Vendas", methods=["GET"])
def listar_relatorios_vendas():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Relatórios de vendas enviados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar relatórios de vendas."}

@app.route("/Relatorios/Vendas/<int:indice>", methods=["GET"])
def visualizar_relatorio_vendas(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Relatório de venda {indice} enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao buscar relatório de venda."}

# RELATÓRIOS DE ESTOQUE

@app.route("/Relatorios/Estoque/Validade", methods=["GET"])
def relatorio_estoque_validade():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Relatório de estoque por validade enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar relatório de estoque por validade."}

@app.route("/Relatorios/Estoque/Quantidade", methods=["GET"])
def relatorio_estoque_quantidade():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Relatório de estoque por quantidade enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar relatório de estoque por quantidade."}


# USUARIOS DESATIVADOS / ATIVADOS / PERMISSÕES

@app.route("/Usuarios/Ativar/<int:indice>", methods=["PUT"])
def ativar_usuario(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Usuário {indice} ativado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao ativar usuário."}

@app.route("/Usuarios/Desativar/<int:indice>", methods=["PUT"])
def desativar_usuario(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Usuário {indice} desativado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao desativar usuário."}

@app.route("/Usuarios/Permissoes/<int:indice>", methods=["PUT"])
def atualizar_permissoes_usuario(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Permissões do usuário {indice} atualizadas com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao atualizar permissões do usuário."}

@app.route("/Alertas/Estoque/Baixo", methods=["GET"])
def alertas_estoque_baixo():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Alertas de estoque baixo enviados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao buscar alertas de estoque."}

@app.route("/Alertas/Estoque/Vencimento", methods=["GET"])
def alertas_estoque_vencimento():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Alertas de vencimento enviados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao buscar alertas de vencimento."}

# NOTIFICAÇÕES GERAIS

@app.route("/Notificacoes", methods=["GET"])
def listar_notificacoes():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Notificações enviadas com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar notificações."}

@app.route("/Notificacoes", methods=["POST"])
def criar_notificacao():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Notificação criada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao criar notificação."} 

# RELATÓRIOS AVANÇADOS (ideia do murylo, utilidade?)

@app.route("/Relatorios/Medicamentos_Controlados", methods=["GET"])
def relatorio_medicamentos_controlados():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Relatório de medicamentos controlados enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar relatório de medicamentos controlados."}

@app.route("/Relatorios/Fornecedores", methods=["GET"])
def relatorio_fornecedores():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Relatório de fornecedores enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar relatório de fornecedores."}

@app.route("/Relatorios/Pedidos/Cancelados", methods=["GET"])
def relatorio_pedidos_cancelados():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Relatório de pedidos cancelados enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar relatório de pedidos cancelados."}

@app.route("/Relatorios/Pedidos/Entregues", methods=["GET"])
def relatorio_pedidos_entregues():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Relatório de pedidos entregues enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar relatório de pedidos entregues."}

# ALERTAS FINANCEIROS (baixo lucro? perda de mercadoria? perca de produção?)

@app.route("/Alertas/Financeiro/Pendentes", methods=["GET"])
def alertas_financeiro_pendentes():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Alertas de pagamentos pendentes enviados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar alertas financeiros pendentes."}

@app.route("/Alertas/Financeiro/Recebidos", methods=["GET"])
def alertas_financeiro_recebidos():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Alertas de pagamentos recebidos enviados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar alertas financeiros recebidos."}

# FECHAMENTO DE ESTOQUE (diário, semanal, mensal, semestral, anual)

@app.route("/Estoque_Fechamento/Diario", methods=["GET"])
def fechamento_estoque_diario():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Fechamento diário de estoque enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar fechamento diário de estoque."}

@app.route("/Estoque_Fechamento/Semanal", methods=["GET"])
def fechamento_estoque_semanal():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Fechamento semanal de estoque enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar fechamento semanal de estoque."}

@app.route("/Estoque_Fechamento/Mensal", methods=["GET"])
def fechamento_estoque_mensal():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Fechamento mensal de estoque enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar fechamento mensal de estoque."}

@app.route("/Estoque_Fechamento/Semestral", methods=["GET"])
def fechamento_estoque_semestral():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Fechamento semestral de estoque enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar fechamento semestral de estoque."}

@app.route("/Estoque_Fechamento/Anual", methods=["GET"])
def fechamento_estoque_anual():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Fechamento anual de estoque enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar fechamento anual de estoque."}

# GERECIAMENTO DE LOTES DE PRODUTOS (contagem por lote)

@app.route("/Produtos/Lotes", methods=["GET"])
def listar_lotes():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Lotes de produtos listados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar lotes."}

@app.route("/Produtos/Lotes", methods=["POST"])
def adicionar_lote():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Lote adicionado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao adicionar lote."}

@app.route("/Produtos/Lotes/<int:indice>", methods=["PUT"])
def atualizar_lote(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Lote {indice} atualizado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao atualizar lote."}

@app.route("/Produtos/Lotes/<int:indice>", methods=["DELETE"])
def deletar_lote(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Lote {indice} removido com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao remover lote."}

# PRODUTOS / LOTES / PRODUTOS EM ABASTECIMENTO 

@app.route("/Alertas/Produtos/Proximo_Vencimento", methods=["GET"])
def alertas_proximo_vencimento():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Alertas de produtos próximos do vencimento enviados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao buscar alertas de produtos próximos do vencimento."}

@app.route("/Relatorios/Produtos/Lotes_Validade_Quantidade", methods=["GET"])
def relatorio_lote_validade_quantidade():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Relatório de lotes, validade e quantidade enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar relatório de lotes, validade e quantidade."}

@app.route("/Produtos/Em_abastecimento", methods=["GET"])
def relatorio_abastecimento_produtos():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Produtos em abastacimento listados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar produtos em abastecimento."}

# CONTROLE DE ESTOQUE POR LOCAL (tipo: A1, B1, C3, D4 - contagem por localização física)

@app.route("/Estoque_Local/<int:indice>", methods=["GET"])
def listar_estoque_local(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Estoque do local {indice} listado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar estoque do local."}

@app.route("/Estoque_Local/<int:indice>", methods=["POST"])
def adicionar_produto_local(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Produto adicionado ao local {indice} com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao adicionar produto ao local."}

@app.route("/Estoque_Local/<int:indice>", methods=["PUT"])
def atualizar_produto_local(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Produto atualizado no local {indice} com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao atualizar produto no local."}

@app.route("/Estoque_Local/<int:indice>", methods=["DELETE"])
def deletar_produto_local(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Produto removido do local {indice} com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao remover produto do local."}

# DISTRIBUIDORAS

@app.route("/Distribuidoras", methods=["GET", "POST"])
def destribuidoras():
    if request.method == 'GET':
        return jsonify(Distribuidoras)
    elif request.method == 'POST':
        dado = request.get_json()
        resultado = validar_exemplo(dado)
        if resultado == True:
            return {"valida": True, "Mensagem": "Distribuidora cadastrado com sucesso!"}
        return {"valida": False, "Mensagem": "Erro ao cadastrar distribuidora."}


@app.route("/Distribuidoras/<int:indice>", methods=["GET", "PUT", "DELETE"])
def distribuidor_detalhe(indice):
    if request.method == 'GET':
        if indice < len(Distribuidoras):
            return jsonify(Distribuidoras[indice])
        return jsonify({"erro": "Distribuidor não encontrado"}), 404

    elif request.method == 'PUT':
        dado = request.get_json()
        resultado = validar_exemplo(dado)
        if resultado == True:
            return {"valida": True, "Mensagem": "Dsitribuidor atualizado com sucesso!"}
        return {"valida": False, "Mensagem": "Erro ao atualizar distribuidor."}

    elif request.method == 'DELETE':
        dado = request.get_json()
        resultado = validar_exemplo(dado)
        if resultado == True:
            return {"valida": True, "Mensagem": "Distribuidor removido com sucesso!"}
        return {"valida": False, "Mensagem": "Erro ao remover distribuidor."}
    
# RELATÓRIO DE PROJEÇÃO DE DEMANDA

@app.route("/Projeção_Demanda", methods=["GET"])
def projecao_de_demanda():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Relatórios de projeção de demanda enviados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar relatórios de projeção de demanda."}
    

# CÂMARAS FRIAS

@app.route("/Listar_Câmaras_frias", methods=["GET"])
def listar_camaras_frias():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Câmaras frias listadas com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar câmaras frias."}

@app.route("/Adicionar_Câmaras_frias", methods=["POST"])
def adicionar_camara_fria():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Câmara fria adicionada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao adicionar câmaras frias"}

@app.route("/Atualizar_Câmaras_frias/<int:indice>", methods=["PUT"])
def atualizar_camara_fria(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Câmara fria {indice} atualizado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao atualizar Câmara fria."}

@app.route("/Câmaras_frias/<int:indice>", methods=["DELETE"])
def deletar_camara_fria(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Câmara fria {indice} removida com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao remover Câmara fria."}

# RELATÓRIOS CÂMARAS FRIAS

@app.route("/Histórico_Produtos_Câmaras_Frias", methods=["GET"])
def historico_produtos_camara_fria():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Histórico de produtos da câmara fria listados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar histórico de produtos da câmara fria."}

@app.route("/Histórico_Temperaturas_Câmaras_Frias", methods=["GET"])
def historico_temperaturas_camara_fria():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Histórico de temperatura da câmara fria listados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar histórico de temperatura da câmara fria."}

# RELATÓRIO DE PRODUTOS COM TEMPERATURA CONTROLADA

@app.route("/Relatório_Produtos_Temperatura_Controlada", methods=["GET"])
def historico_produtos_TempControlada():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Relatório de produtos com temperatura controlada listado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar relatório de produtos com temperatura controlada "}

# RELATÓRIOS DE ENTRADA DE PRODUTOS (lotes)

@app.route("/Relatorios_Entrada_Produtos", methods=["GET"])
def relatorio_entradas_produtos():
    resultado = validar_exemplo()
    if resultado == True:
        return {"valida": True, "Mensagem": "Relatório de entrada de produtos ao estoque enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar relatório de entrada de produtos ao estoque"}

# RELATÓRIOS DE SAÍDA DE PRODUTOS (lotes)

@app.route("/Relatorios_Saída_Produtos", methods=["GET"])
def relatorio_saida_produtos():
    resultado = validar_exemplo()
    if resultado == True:
        return {"valida": True, "Mensagem": "Relatório de saída de produtos ao estoque enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar relatório de saída de produtos ao estoque"}

# RELATÓRIO DE PEDIDOS DO ESTOQUE

@app.route("/Relatorios_Pedidos_Estoque", methods=["GET"])
def relatorio_pedidos_estoque():
    resultado = validar_exemplo()
    if resultado == True:
        return {"valida": True, "Mensagem": "Relatório de pedidos do estoque enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar relatório pedidos do estoque"}

# HISTÓRICO DE FECHAMENTOS (diários, semanais, mensais, semestrais, anuais)

@app.route("/Histórico_Fechamento_Diário", methods=["GET"])
def historico_fechamento_diario():
    resultado = validar_exemplo()
    if resultado == True:
        return {"valida": True, "Mensagem": "Histórico de fechamento diário enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar histórico de fechamento diário"}

@app.route("/Histórico_Fechamento_Semanal", methods=["GET"])
def historico_fechamento_semanal():
    resultado = validar_exemplo()
    if resultado == True:
        return {"valida": True, "Mensagem": "Histórico de fechamento semanal enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar histórico de fechamento semanal"}

@app.route("/Histórico_Fechamento_Mensal", methods=["GET"])
def historico_fechamento_mensal():
    resultado = validar_exemplo()
    if resultado == True:
        return {"valida": True, "Mensagem": "Histórico de fechamento mensal enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar histórico de fechamento mensal"}

@app.route("/Histórico_Fechamento_Semestral", methods=["GET"])
def historico_fechamento_semestral():
    resultado = validar_exemplo()
    if resultado == True:
        return {"valida": True, "Mensagem": "Histórico de fechamento semestral enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar histórico de fechamento semestral"}

@app.route("/Histórico_Fechamento_Anual", methods=["GET"])
def historico_fechamento_anual():
    resultado = validar_exemplo()
    if resultado == True:
        return {"valida": True, "Mensagem": "Histórico de fechamento anual enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar histórico de fechamento anual"}

# RELATÓRIO DE PERDAS POR VENCIMENTO

@app.route("/Relatório_Perdas_Vencimento", methods=["GET"])
def relatorio_perda_vencimento():
    resultado = validar_exemplo()
    if resultado == True:
        return {"valida": True, "Mensagem": "Relatório de perdas de produtos por vencimento enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar relatório de perdas de produtos por vencimento"}

# LOCALIZAÇÃO FÍSICA DO ESTOQUE

@app.route("/Listar_localização_física", methods=["GET"])
def listar_localização_fisica():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Localizações físicas do estoque listadas com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar localizações físicas do estoque."}

@app.route("/Atualizar_localização_física/<int:indice>", methods=["PUT"])
def atualizar_localização_fisica(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"localização física do estoque {indice} atualizado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao atualizar localização física do estoque."}

@app.route("/Deletar_localização_física/<int:indice>", methods=["DELETE"])
def deletar_localização_fisica(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"localização física do estoque {indice} removida com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao remover localização física do estoque."}

@app.route("/Adicionar_Localização", methods=["POST"])
def adicionar_localizacao():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Localização física adicionada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao adicionar localização física."}

# TRANFERÊNCIA DE PRODUTO ENTRE LOCALIZAÇÕES FÍSICAS DO ESTOQUE

@app.route("/Transferir_Produto", methods=["POST"])
def transferir_produto():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Transferência de produto realizada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao transferir produto entre setores."}

# TRANFERÊNCIA DE LOTE ENTRE LOCALIZAÇÕES FÍSICAS DO ESTOQUE

@app.route("/Transferir_Lote", methods=["POST"])
def transferir_lote():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Transferência de lote realizada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao transferir lote entre setores."}

# RELATÓRIO TRANFERÊNCIA DE PRODUTO ENTRE LOCALIZAÇÕES FÍSICAS DO ESTOQUE

@app.route("/Relatório_Transferir_Produto", methods=["GET"])
def historico_transferir_produto():
    resultado = validar_exemplo()
    if resultado == True:
        return {"valida": True, "Mensagem": "Histórico de tranferências de produtos entre as localizações do estoque enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar histórico de tranferências de produtos entre as localizações do estoque"}

# RELATÓRIO TRANFERÊNCIA DE LOTES ENTRE LOCALIZAÇÕES FÍSICAS DO ESTOQUE

@app.route("/Relatório_Transferir_Lote", methods=["GET"])
def historico_transferir_lote():
    resultado = validar_exemplo()
    if resultado == True:
        return {"valida": True, "Mensagem": "Histórico de tranferências de lote entre as localizações do estoque enviado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar histórico de tranferências de lote entre as localizações do estoque"}

# RELATÓRIO DE MOVIMENTAÇÕES INTERNAS DO ESTOQUE (ex: tudo da área A1 foi para a C5)

@app.route("/Histórico_Movimentacõess", methods=["GET"])
def historico_movimentacoes_internas():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Histórico de movimentações carregado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar histórico de movimentações."}

# LOGS DE USUÁRIOS

@app.route("/logs_usuários", methods=["GET"])
def listar_logs_usuario():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Logs dos usuários listados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar logs dos usuários"}

@app.route("/logs_usuários_atualizar/<int:indice>", methods=["PUT"])
def atualizar_logs_usuario(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"logs dos usuários {indice} atualizados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao atualizar logs dos usuarios"}

@app.route("/logs_usuários_deletar/<int:indice>", methods=["DELETE"])
def deletar_logs_usario(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"logs do usuario {indice} removido com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao remover log dos usuarios"}

@app.route("/logs_usuários_adicionar", methods=["POST"])
def adicionar_log_usuario():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "log de usuário adicionada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao adicionar log de usuário"}

# LOGS DE ADMINISTRADORES (AUDITORIA)

@app.route("/logs_administradores", methods=["GET"])
def listar_logs_dministradores():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Logs dos administradores listados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar logs dos administradores"}

@app.route("/logs_administradores_atualizar/<int:indice>", methods=["PUT"])
def atualizar_logs_administradores(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"logs dos administradores {indice} atualizados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao atualizar logs dos administradores"}

@app.route("/logs_administradores_deletar/<int:indice>", methods=["DELETE"])
def deletar_logs_administradores(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"logs do administradores {indice} removido com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao remover log dos administradores"}

@app.route("/logs_administradores_adicionar", methods=["POST"])
def adicionar_log_administradores():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "log de administradores adicionada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao adicionar log de administradores"}

# DOCUMENTAÇÃO EMPRESA (licensas, notas, etc)

@app.route("/documentação_empresa", methods=["GET"])
def listar_documentacao_empresa():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Documentos da empresa listados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar documentos da empresa"}

@app.route("/documentação_empresa_atualizar/<int:indice>", methods=["PUT"])
def atualizar_documentacao_empresa(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Documentos da empresa {indice} atualizados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao atualizar documentos da empresa"}

@app.route("/documentação_empresa_deletar/<int:indice>", methods=["DELETE"])
def deletar_documentacao_empresa(indice):
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": f"Documento da empresa {indice} removido com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao remover documento da empresa"}

@app.route("/documentação_empresa_adicionar", methods=["POST"])
def adicionar_documentacao_empresa():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Documento da empresa adicionada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao adicionar documento da empresa"}

# DOCUMENTAÇÃO - CATEGORIAS

@app.route("/documentação_categorias", methods=["GET"])
def listar_documentacao_empresa_categorias():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Categorias de documentos da empresa listados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar categoris de documentos da empresa"}

@app.route("/documentação_categoria_adicionar", methods=["POST"])
def adicionar_documentacao_categoria_empresa():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "   Categoria de documento da empresa adicionada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao adicionar categoria de documento da empresa"}

# COMUNICAÇÃO

@app.route("/Comunicação/Mensagens", methods=["GET"])
def listar_mensagens():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Mensagens listadas com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar mensgens"}

@app.route("/Comunicação/Mensagens", methods=["POST"])
def adicionar_mensagem():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Mensagem adicionada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao adicionar mensagem"}

@app.route("/Comunicação/Mensagens/<int:indice>", methods=["GET"])
def procurar_mensagem():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Mensagem encontrada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao procurar mensagem"}

@app.route("/Comunicação/Mensagens/<int:indice>", methods=["PUT"])
def atualizar_mensagem():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Mensagem atualizada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao atualizar mensagem"}

@app.route("/Comunicação/Mensagens/<int:indice>", methods=["DELETE"])
def deletar_mensagem():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Mensagem deletada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao deletar mensagem"}

# COMUNICÃO - GRUPOS

@app.route("/Comunicação/Grupos", methods=["GET"])
def listar_grupos_comunicacao():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Grupo de mensagens encontrado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao procurar grupo de mensagens"}

@app.route("/Comunicação/Grupos", methods=["POST"])
def adicionar_grupo_comunicacao():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Grupo de mensagens adicionado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao adicionar grupo de mensagens"}

# COMUNICÃO - ANEXO

@app.route("/Comunicação/Anexo", methods=["POST"])
def adicionar_anexo():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Anexo adicionado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao adicionar anexo"}

# COMUNICÃO - NOTIFICAÇÕES

@app.route("/Comunicação/Notificações", methods=["GET"])
def listar_comunicacao_notificacoes():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Notificação listada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao encontrar notificação"}

# IOT - SENSORES

@app.route("/IoT/Sensores", methods=["GET"])
def listar_sensores():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Sensores listados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar sensores"}

@app.route("/IoT/Sensores", methods=["POST"])
def adicionar_sensor():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Sensor adicionado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao adicionar sensor"}

@app.route("/IoT/Sensores/int:id", methods=["GET"])
def procurar_sensor():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Sensor encontrado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao procurar sensor"}

@app.route("/IoT/Sensores/int:id", methods=["PUT"])
def atualizar_sensor():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Sensor atualizado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao atualizar sensor"}

@app.route("/IoT/Sensores/int:id", methods=["DELETE"])
def deletar_sensor():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Sensor deletada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao deletar sensor"}

# IOT - SENSORES - LEITURA DE DADOS

@app.route("/IoT/Dados/<int:sensor_id>", methods=["GET"])
def listar_leituras_sensores():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Leituras dos sensores listados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar leituras dos sensores"}

# IOT - SENSORES - ALERTAS

@app.route("/IoT/Alertas", methods=["GET"])
def listar_sensores_alertas():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Alertas dos sensores listados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar alertas dos sensores"}

# IOT - SENSORES - ALERTAS

@app.route("/IoT/Status_Rede", methods=["GET"])
def listar_sensores_status():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Status de rede dos sensores listados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar status de rede dos sensores"}

# INTEGRAÇÕES COM O GOVERNO FEDERAL - REGULATÓRIOS - RECEITA FEDERAL

@app.route("/Integração/Gov/ReceitaFedera", methods=["GET"])
def listar_regulacao_receita_federal():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Regulações do governo federal listados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar regulações do governo federal"}

@app.route("/Integração/Gov/ReceitaFedera", methods=["POST"])
def adicionar_regulacao_receita_federal():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Regulação do governo federal adicionado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao adicionar regulação do governo federal."}

# INTEGRAÇÕES COM O GOVERNO FEDERAL - REGULATÓRIOS - ANVISA

@app.route("/Integração/Gov/Anvisa", methods=["GET"])
def listar_regulacao_anvisa():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Regulações da Anvisa listados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar regulações da Anvisa"}

@app.route("/Integração/Gov/Anvisa", methods=["POST"])
def adicionar_regulacao_anvisa():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Regulação da Anvisa adicionada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao adicionar regulação da Anvisa."}

# INTEGRAÇÕES COM O GOVERNO FEDERAL - REGULATÓRIOS - SEFAZ (NFs)

@app.route("/Integração/Gov/Sefaz", methods=["GET"])
def listar_regulacao_sefaz():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Regulações da Sefaz listados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar regulações da Sefaz"}

# INTEGRAÇÕES COM O GOVERNO FEDERAL - REGULATÓRIOS - RELATÓRIOS

@app.route("/Integração/Gov/Relatórios", methods=["GET"])
def listar_regulacao_relatorios():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Relatórios de regulações listados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar relatórios das regulações"}

# INSPEÇÕES DE QUALIDADE

@app.route("/Qualidade/Inspecoes", methods=["GET"])
def listar_inpecoes_qualidade():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Inspeções de qualidade listados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar inspeções de qualidade"}

@app.route("/Qualidade/Inspecoes", methods=["POST"])
def adicionar_inspecao_qualidade():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Inspeção de qualidade adicionado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao adicionar inspeção de qualidade"}

@app.route("/Qualidade/Inspecoes/<int:id>", methods=["GET"])
def procurar_inspecao_qualidade():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Inspeção de qualidade encontrada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao procurar inspeção de qualidade"}

@app.route("/Qualidade/Inspecoes/<int:id>", methods=["PUT"])
def atualizar_inspecao_qualidade():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Inspeção de qualidade atualizada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao atualizar inspeção de qualidade"}

@app.route("/Qualidade/Inspecoes/<int:id>", methods=["DELETE"])
def deletar_inspecao_qualidade():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Inspeção de qualidade deletada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao deletar inspeção de qualidade"}

# INSPEÇÕES DE QUALIDADE - RELATÓRIOS DE NC (não conformidades encontradas)

@app.route("/Qualidade/Relatorio_NC", methods=["GET"])
def listar_inspecoes_qualidade():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Inspeções de qualidade listados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar inspeções de qualidade"}

# INSPEÇÕES DE QUALIDADE - STATUS (em haver, marcada, em andamento, finalizada)

@app.route("/Qualidade/Atualizar_Status", methods=["PUT"])
def atualizar_inspecao_qualidade_status():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Status da inspeção de qualidade atualizada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao atualizar status da inspeção de qualidade"}

# INSPEÇÕES DE QUALIDADE - CERTIFICADOS

@app.route("/Qualidade/Certificados", methods=["GET"])
def listar_inspecoes_qualidade_certificados():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Certificados de inspeções de qualidade listados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar certificados de inspeções de qualidade"}

# MANUTENÇÃO - BACKUP, LOGS DE ERRO E CONFIGURAÇÕES

@app.route("/Sistema/Backup/Diario", methods=["POST"])
def backup_diario():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Backup diário salvo com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao salvar backup diário"}

# Restaurar por backup

@app.route("/Sistema/Backup/Restaurar/<string:data>", methods=["POST"])
def backup_restaurar():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Restauração via backup realizado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao restaurar via backup"}

# Configurações

@app.route("/Sistema/Configurações", methods=["GET"])
def listar_configuracoes_sistema():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Configurações do sistema listados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar configurações do sistem"}

@app.route("/Qualidade/Inspecoes", methods=["PUT"])
def atualizar_configuracao_sistema():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Configuração do sistema atualizado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao atualizar configuração do sistema"}

# Logs de erro

@app.route("/Sistema/Logs/Erro", methods=["GET"])
def listar_logs_erro():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Logs de erro do sistema listados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar logs de erro do sistema"}

# SEGURANÇA / AUDITORIA - TOKENS

@app.route("/Auditoria/Logs_Login", methods=["GET"])
def listar_logs_login():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Logs de login listados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar logs de login do sistema"}

# Alterações da auditoria

@app.route("/Auditoria/Alteracoes/<string:entidade>", methods=["GET"])
def auditoria_alteracoes():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Alterações da audiretoria listados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar alterações da audiretoria"}

# Autenticação do token

@app.route("/Seguranca/Autenticação_Token", methods=["POST"])
def autenticacao_token():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Autenticação do token solicitado com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao gerar autenticação de token de acesso"}

# Revogar token

@app.route("/Seguranca/Revogar_Token/<string:token_id>", methods=["DELETE"])
def revogar_autenticacao_token():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Autenticação de token deletada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao deletar autenticação de token"}

# Logs de ações de usuário do sistema

@app.route("/Usuarios/Atividades/<int:indice>", methods=["GET"])
def logs_usuarios_atividades():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Logs de atividades de usuários listados com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar logs de atividades de usuários"}

# METAS (DESEMPENHO)

@app.route("/listar_metas", methods=["GET"])
def listar_metas():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Metas listadas com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar metas"}

@app.route("/Metas", methods=["POST"])
def adicionar_metas():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Meta adicionada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao adicionar meta"}

@app.route("/Metas/<int:indice>", methods=["GET"])
def procurar_meta():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Meta encontrada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao procurar meta"}

@app.route("/Metas/<int:indice>", methods=["PUT"])
def atualizar_meta():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Meta atualizada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao atualizar meta"}

@app.route("/Metas/<int:indice>", methods=["DELETE"])
def deletar_meta():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Meta deletada com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao deletar meta"}

# METAS - RELATÓRIOS

@app.route("/Relatórios_Gerais_Metas", methods=["GET"])
def relatorios_gerais_metas():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Relatórios ds metas listadas com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar relatórios das metas"}

# METAS - RELATÓRIOS DE DESEMPENHO

@app.route("/Relatórios_Desempenho_Metas", methods=["GET"])
def relatorios_desempenho_metas():
    dado = request.get_json()
    resultado = validar_exemplo(dado)
    if resultado == True:
        return {"valida": True, "Mensagem": "Relatórios de desenpenho das metas listadas com sucesso!"}
    return {"valida": False, "Mensagem": "Erro ao listar relatórios de desempenho das metas"}

# EXECUTAR

if __name__ == "__main__":
    app.run(debug=True)

